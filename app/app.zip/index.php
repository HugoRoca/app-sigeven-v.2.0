<?php

//redireccionar a la vista login
header('Location: views/login.html');

?>