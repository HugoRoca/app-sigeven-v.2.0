    <footer class="main-footer">
        <div class="pull-right hidden-xs">
        Sistema de Ventas
        </div>
        <strong>Copyright &copy; 2018 <a href="#">Hugo Roca</a>.</strong> All rights reserved.
    </footer>
    <div class="control-sidebar-bg"></div>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/adminlte.min.js"></script>

    <script src="../assets/js/jquery.datatables.min.js"></script>
    <script src="../assets/js/datatables.buttons.min.js"></script>
    <script src="../assets/js/buttons.html5.min.js"></script>
    <script src="../assets/js/buttons.colVis.min.js"></script>
    <script src="../assets/js/jszip.min.js"></script>
    <script src="../assets/js/pdfmake.min.js"></script>
    <script src="../assets/js/vfs_fonts.js"></script>

    <script src="../assets/js/bootbox.min.js"></script>
    <script src="../assets/js/bootstrap-select.min.js"></script>
    <script src="scripts/utils.js"></script>
</body>
</html>