<div class="content-wrapper">
    <section class="content-header">
      <h1>
        Sin acceso
        <small>Comuníquese con el administrador de sistemas.</small>
      </h1>
    </section>
</div>
